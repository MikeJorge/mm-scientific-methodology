# MM Methodology v1.0.2 — Scientific reproducibility supplement

This **versioned, non-normative** public supplement accompanies the MM Scientific Software Development Methodology v1.0.2. It contains **12 exact source files** previously classified under W12: two Python/Matplotlib figure generators, the verified Figure 1 asset manifest, and nine machine-readable methodology/audit-data JSON records. The scientific methodology's certified authority remains its original architecture, manual, evidence base and certified Git commits; these supplementary files do not create runtime authorization.

The files listed in `SUPPLEMENT_SOURCE_MANIFEST.json` reproduce their source-staging bytes **without modification**. They may be inspected or reused consistent with the applicable attribution and licensing terms; they are **not** supplied as a tested, installable or production-ready Python package. The two generators depend on an appropriate Python plotting environment and are not executed during this publication process. Public release here does not assert that recreating every PDF—including embedded metadata—will yield byte-identical results.

**Figure 1:** the included v1.0.3 manifest identifies the current SVG/PDF/PNG assets by byte size and SHA-256. Its detailed accessible description appears on the figure page.

**Figure 2:** the older v1.0.6 manifest is **intentionally absent** because its PDF identity differs from the current publication-selected PDF. The selected PDF is 61,763 bytes, SHA-256 `8fa10c936bc545c55aa315f5471f7a09b7e19f9bb0292143344f5844870bfded`; see `PROVENANCE_AND_RIGHTS.md`. The PDF includes Content Credentials metadata associated with ChatGPT handling, whose signature has not been independently verified here. This statement neither establishes image generation by an AI image model nor overrides the Python/Matplotlib source account.

**Licensing and attribution:** this supplement includes the original project's MIT `LICENSE` (copyright 2024 Michael Allim Jorge) for applicable original software and associated project documentation. Citations, externally authored standards and third-party works in the source register are **not relicensed** by this supplement. See `PROVENANCE_AND_RIGHTS.md`. No raw internal assurance receipt, historical manifest for Figure 2, credential, CI log or unpublished administrative record is included.

Site edition: `https://mikejorge.github.io/modulo-minimo-MHSMM/` (target URL; deployment separately authorized).
