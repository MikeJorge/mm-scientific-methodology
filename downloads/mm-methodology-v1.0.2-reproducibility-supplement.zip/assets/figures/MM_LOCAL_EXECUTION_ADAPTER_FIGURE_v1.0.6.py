#!/usr/bin/env python3
"""
MM Local Execution Adapter and Controlled Development Environment Figure v1.0.5

Targeted remediation of Figure 2 v1.0.0 findings FIG2-M01..M03 and E02.
Deterministic Python/Matplotlib line-art generator.
No generative-image model or external image-generation service is used.

The figure is a non-normative local implementation view subordinate to Figure 1.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import math
import os
from pathlib import Path
import xml.etree.ElementTree as ET
import fitz
import re

os.environ.setdefault("SOURCE_DATE_EPOCH", "1794355200")

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, PathPatch
from matplotlib.path import Path as MplPath
from matplotlib import font_manager

VERSION = "1.0.6"
FIGURE_ID = "MM-LOCAL-EXECUTION-ADAPTER-FIGURE"
WIDTH_MM = 180.0
HEIGHT_MM = 165.0
PNG_DPI = 300
FONT_MIN_PT = 5.0
FONT_MAX_PT = 7.0
FONT_FAMILY = "Liberation Sans"
TITLE = "Qualified local execution adapter and controlled development environment for the Module Minimum (MM) system"
RUNTIME_BOUNDARY_TEXT = "QUALIFIED LOCAL ADAPTER DOES NOT AUTHORIZE PRIMARY SCIENTIFIC RUNTIME"

# Connector microgeometry publication profile (final-size millimetres / points).
FLOW_ARROWHEAD_SCALE_PT = 5.8
MIN_ENDPOINT_CORNER_CLEARANCE_MM = 3.0
MIN_TERMINAL_STRAIGHT_MM = 3.0
LOCAL_VISIBLE_TERMINAL_TARGET_MM = 3.25
MIN_PARALLEL_LANE_SEPARATION_MM = 1.5
MIN_CONNECTOR_TEXT_CLEARANCE_MM = 1.5
MIN_CONNECTOR_PANEL_CLEARANCE_MM = 1.0

# One actual installed TrueType family is used for geometric layout and all exports.
FONT_PATH = Path(font_manager.findfont(FONT_FAMILY, fallback_to_default=False))
if not FONT_PATH.exists() or FONT_PATH.suffix.lower() not in {".ttf", ".ttc"}:
    raise RuntimeError(f"Publication font not resolved to installed TrueType: {FONT_PATH}")

mpl.rcParams["svg.hashsalt"] = "mm-local-execution-adapter-v1.0.6"
mpl.rcParams["svg.fonttype"] = "none"
mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["pdf.use14corefonts"] = False
mpl.rcParams["font.family"] = "sans-serif"
mpl.rcParams["font.sans-serif"] = [FONT_FAMILY]
mpl.rcParams["savefig.transparent"] = False
mpl.rcParams["axes.unicode_minus"] = False

USED_FONT_SIZES: set[float] = set()
USED_LINE_WIDTHS: set[float] = set()
BOX_BINDINGS = []
PATCH_BINDINGS = []
FREE_TEXT_BINDINGS = []
CONNECTOR_ASSERTIONS = []
CONNECTOR_PATHS = []
ASSOCIATION_ASSERTIONS = []

PALETTE = {
    "host_fill": "#EAF2F8", "host_edge": "#2F5D7C",
    "readonly_fill": "#DCEAF7", "readonly_edge": "#285A7A",
    "mutable_fill": "#FFF1CC", "mutable_edge": "#7A6518",
    "toolchain_fill": "#ECE6F6", "toolchain_edge": "#6B4C8A",
    "admin_fill": "#FBE7D4", "admin_edge": "#9A6324",
    "executor_fill": "#DDF3F0", "executor_edge": "#2A756D",
    "review_fill": "#EAF2F8", "review_edge": "#2F5D7C",
    "neutral_fill": "#F7F7F7", "neutral_edge": "#5B5B5B",
    "state_fill": "#EFEFEF", "state_edge": "#4B4B4B",
    "hold_fill": "#F7EAD5", "hold_edge": "#80622A",
}


def _font(size: float) -> float:
    USED_FONT_SIZES.add(float(size))
    return float(size)


def _lw(width: float) -> float:
    USED_LINE_WIDTHS.add(float(width))
    return float(width)


def add_box(ax, x, y, w, h, text, *, fontsize=5.2, weight="normal",
            rounded=True, lw=0.6, linestyle="-", align="center",
            facecolor="white", edgecolor="black", zorder=2,
            qa_margin_mm=0.55, qa_name=None):
    if rounded:
        patch = FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.45,rounding_size=0.8",
            linewidth=_lw(lw), edgecolor=edgecolor, facecolor=facecolor,
            linestyle=linestyle, zorder=zorder,
        )
    else:
        patch = Rectangle(
            (x, y), w, h,
            linewidth=_lw(lw), edgecolor=edgecolor, facecolor=facecolor,
            linestyle=linestyle, zorder=zorder,
        )
    ax.add_patch(patch)
    patch_name = qa_name or f"box_{len(PATCH_BINDINGS)+1}"
    if qa_name:
        patch.set_gid("panel-" + re.sub(r"[^a-z0-9]+", "-", qa_name.lower()).strip("-"))
    PATCH_BINDINGS.append({"name": patch_name, "patch": patch, "rect": (x, y, w, h)})
    text_artist = None
    if text:
        ha = {"left": "left", "center": "center", "right": "right"}[align]
        tx = x + (1.4 if align == "left" else (w - 1.4 if align == "right" else w / 2))
        text_artist = ax.text(
            tx, y + h / 2, text, ha=ha, va="center",
            fontsize=_font(fontsize), fontweight=weight,
            zorder=zorder + 1, linespacing=1.08,
        )
        BOX_BINDINGS.append({
            "name": qa_name or text.split("\n")[0][:48],
            "patch_name": patch_name,
            "patch": patch,
            "text": text_artist,
            "margin_mm": float(qa_margin_mm),
        })
    return patch, text_artist



def add_free_text(ax, x, y, text, *, name, fontsize=5.0, weight="normal",
                  color="black", ha="center", va="center", allowed_patches=None,
                  zorder=4, bbox=None):
    artist = ax.text(x, y, text, ha=ha, va=va, fontsize=_font(fontsize),
                     fontweight=weight, color=color, zorder=zorder, bbox=bbox)
    FREE_TEXT_BINDINGS.append({
        "name": name,
        "text": artist,
        "allowed_patches": set(allowed_patches or []),
    })
    return artist


def _rect_contains_rect(outer, inner, tol=1e-9):
    ox, oy, ow, oh = outer
    ix, iy, iw, ih = inner
    return (ix >= ox - tol and iy >= oy - tol and
            ix + iw <= ox + ow + tol and iy + ih <= oy + oh + tol)


def _bbox_overlap(a, b, tol_px=0.0):
    return not (a.x1 <= b.x0 + tol_px or a.x0 >= b.x1 - tol_px or
                a.y1 <= b.y0 + tol_px or a.y0 >= b.y1 - tol_px)


def _segment_intersects_rect_interior(p1, p2, rect, tol=0.02):
    # Liang-Barsky clipping against a slightly shrunken rectangle interior.
    x, y, w, h = rect
    xmin, xmax = x + tol, x + w - tol
    ymin, ymax = y + tol, y + h - tol
    x1, y1 = p1; x2, y2 = p2
    dx, dy = x2-x1, y2-y1
    p = [-dx, dx, -dy, dy]
    q = [x1-xmin, xmax-x1, y1-ymin, ymax-y1]
    u1, u2 = 0.0, 1.0
    for pi, qi in zip(p, q):
        if abs(pi) < 1e-12:
            if qi < 0:
                return False
            continue
        t = qi/pi
        if pi < 0:
            if t > u2: return False
            if t > u1: u1 = t
        else:
            if t < u1: return False
            if t < u2: u2 = t
    return u1 < u2 and u2 > 0 and u1 < 1


def _point_in_rect(px, py, rect, tol=0.0):
    x,y,w,h=rect
    return x-tol <= px <= x+w+tol and y-tol <= py <= y+h+tol


def _validate_connector_grammar(relation_type, arrowhead):
    """Production connector grammar; fail closed for unsupported combinations."""
    allowed = {"identity_binding", "access_flow", "containment", "platform_transition"}
    if relation_type not in allowed:
        raise ValueError(f"UNSUPPORTED_CONNECTOR_RELATION:{relation_type}")
    if relation_type == "identity_binding" and arrowhead:
        raise ValueError("IDENTITY_BINDING_ARROWHEAD_FORBIDDEN")
    if relation_type == "access_flow" and not arrowhead:
        raise ValueError("ACCESS_FLOW_ARROWHEAD_REQUIRED")
    return True


def _run_negative_fixtures():
    results = []
    # 1 own-box text overflow detector
    box=(0,0,10,5); text=(1,1,10.5,4)
    results.append(("own_box_text_overflow", not _rect_contains_rect(box, (text[0],text[1],text[2]-text[0],text[3]-text[1]))))
    # 2 text crossing neighboring box
    results.append(("text_crosses_neighbor", _rects_overlap_numeric((0,0,4,2),(3.5,0,4,2))))
    # 3 free label crosses panel edge
    results.append(("free_label_crosses_panel", _rects_overlap_numeric((9.5,2,2,1),(0,0,10,5))))
    # 4 connector label crosses unrelated node
    results.append(("connector_label_crosses_node", _rects_overlap_numeric((5,5,3,1),(6,4.5,4,3))))
    # 5 generic filesystem target rejected
    fs=(0,0,100,30); output=(40,10,15,10); pt=(100,15)
    results.append(("generic_fs_write_rejected", _point_on_rect_boundary(*pt, fs) and not _point_on_rect_boundary(*pt, output)))
    # 6 generic filesystem evidence source rejected
    review=(20,10,15,10); pt2=(100,7)
    results.append(("generic_fs_evidence_rejected", _point_on_rect_boundary(*pt2, fs) and not _point_on_rect_boundary(*pt2, review)))
    # 7 whitespace endpoint rejected
    results.append(("whitespace_endpoint_rejected", not _point_on_rect_boundary(70,70,(0,0,10,10))))
    # 8 connector body crossing another connector's label must be detected.
    other_label_rect=(5,4.5,3,1.0)
    results.append(("connector_crosses_other_connector_label",
                    _segment_intersects_rect_interior((0,5),(10,5),other_label_rect,tol=0.01)))
    # 9 access endpoint in rounded-corner zone rejected.
    results.append(("corner_endpoint_rejected",
                    _corner_clearance_mm((0,0.5),(0,0,10,10),"left") < MIN_ENDPOINT_CORNER_CLEARANCE_MM))
    # 10 sub-minimum terminal segment rejected.
    results.append(("short_terminal_segment_rejected",
                    _segment_length_mm((0,0),(2.0,0)) < MIN_TERMINAL_STRAIGHT_MM))
    # 11 real malformed identity relation with an arrowhead must be rejected
    # by the same production grammar used by normal connector construction.
    try:
        _validate_connector_grammar("identity_binding", True)
        identity_arrowhead_detected = False
    except ValueError as exc:
        identity_arrowhead_detected = str(exc) == "IDENTITY_BINDING_ARROWHEAD_FORBIDDEN"
    results.append(("identity_arrowhead_rejected", identity_arrowhead_detected))
    # 12 non-perpendicular target incidence rejected.
    results.append(("nonperpendicular_incidence_rejected",
                    not _perpendicular_incidence([(0,0),(2,2)],"left")))
    return [{"name": n, "detected": bool(v)} for n,v in results]


def _rects_overlap_numeric(a,b,tol=0.0):
    ax,ay,aw,ah=a; bx,by,bw,bh=b
    return not (ax+aw <= bx+tol or bx+bw <= ax+tol or ay+ah <= by+tol or by+bh <= ay+tol)


def add_arrow(ax, x1, y1, x2, y2, *, lw=0.6, linestyle="-",
              mutation_scale=7.2, zorder=1, color="black", gid=None):
    a = FancyArrowPatch(
        (x1, y1), (x2, y2), arrowstyle="-|>",
        mutation_scale=mutation_scale, linewidth=_lw(lw),
        linestyle=linestyle, color=color, shrinkA=0, shrinkB=0,
        zorder=zorder,
    )
    if gid:
        a.set_gid(gid)
    ax.add_patch(a)
    return a


def _draw_polyline(ax, points, *, lw=0.55, color="black", linestyle="-", zorder=1):
    if len(points) < 2:
        raise ValueError("polyline requires >=2 points")
    verts = points
    codes = [MplPath.MOVETO] + [MplPath.LINETO] * (len(verts) - 1)
    patch = PathPatch(MplPath(verts, codes), fill=False,
                      linewidth=_lw(lw), edgecolor=color,
                      linestyle=linestyle, zorder=zorder)
    ax.add_patch(patch)
    return patch


def add_poly_arrow(ax, points, *, lw=0.55, color="black", label=None,
                   label_xy=None, label_size=5.0, zorder=1, label_allowed_patches=None,
                   label_color="black", arrowhead_scale=FLOW_ARROWHEAD_SCALE_PT, connector_id=None):
    # ACCESS FLOW grammar: directed line with a standardized final arrowhead.
    _validate_connector_grammar("access_flow", True)
    if len(points) < 2:
        raise ValueError("poly arrow requires >=2 points")
    if len(points) > 2:
        _draw_polyline(ax, points[:-1], lw=lw, color=color, zorder=zorder)
    add_arrow(ax, *points[-2], *points[-1], lw=lw, color=color,
              mutation_scale=arrowhead_scale, zorder=zorder,
              gid=(f"terminal-{connector_id}" if connector_id else None))
    if label and label_xy:
        add_free_text(ax, label_xy[0], label_xy[1], label, name=f"connector label:{label}",
                      fontsize=label_size, weight="bold", color=label_color,
                      allowed_patches=set(label_allowed_patches or []),
                      bbox=dict(facecolor="white", edgecolor="none", pad=0.32),
                      zorder=zorder + 2)


def add_poly_association(ax, points, *, lw=0.55, color="black", label=None,
                         label_xy=None, label_size=5.0, zorder=1,
                         label_allowed_patches=None, connector_id=None):
    # IDENTITY BINDING grammar: non-directional association, never an arrow.
    _validate_connector_grammar("identity_binding", False)
    patch = _draw_polyline(ax, points, lw=lw, color=color, zorder=zorder)
    if connector_id:
        patch.set_gid(f"association-{connector_id}")
    if label and label_xy:
        add_free_text(ax, label_xy[0], label_xy[1], label,
                      name=f"association label:{label}",
                      fontsize=label_size, weight="bold", color="black",
                      allowed_patches=set(label_allowed_patches or []),
                      bbox=dict(facecolor="white", edgecolor="none", pad=0.32),
                      zorder=zorder + 2)
    return patch


def add_line(ax, x1, y1, x2, y2, *, lw=0.55, linestyle="-", color="black", zorder=1):
    ax.plot([x1, x2], [y1, y2], linewidth=_lw(lw), linestyle=linestyle,
            color=color, zorder=zorder)


def header(ax, x, y, text):
    return add_free_text(ax, x, y, text, name=f"header:{text}", fontsize=6.4,
                         weight="bold", ha="left", va="center")


def _point_on_rect_boundary(px, py, rect, tol=0.06):
    x, y, w, h = rect
    within_x = x - tol <= px <= x + w + tol
    within_y = y - tol <= py <= y + h + tol
    on_vertical = within_y and (abs(px - x) <= tol or abs(px - (x+w)) <= tol)
    on_horizontal = within_x and (abs(py - y) <= tol or abs(py - (y+h)) <= tol)
    return on_vertical or on_horizontal


def _boundary_side(point, rect, tol=0.06):
    px, py = point
    x, y, w, h = rect
    sides = []
    if y - tol <= py <= y + h + tol:
        if abs(px - x) <= tol:
            sides.append("left")
        if abs(px - (x+w)) <= tol:
            sides.append("right")
    if x - tol <= px <= x + w + tol:
        if abs(py - y) <= tol:
            sides.append("bottom")
        if abs(py - (y+h)) <= tol:
            sides.append("top")
    return sides


def _corner_clearance_mm(point, rect, side):
    px, py = point
    x, y, w, h = rect
    if side in {"left", "right"}:
        return min(py-y, y+h-py)
    if side in {"top", "bottom"}:
        return min(px-x, x+w-px)
    raise ValueError(side)


def _segment_length_mm(p1, p2):
    return math.hypot(p2[0]-p1[0], p2[1]-p1[1])


def _perpendicular_incidence(points, target_side, tol=1e-6):
    if len(points) < 2:
        return False
    p1, p2 = points[-2], points[-1]
    dx, dy = p2[0]-p1[0], p2[1]-p1[1]
    if target_side in {"left", "right"}:
        return abs(dy) <= tol and abs(dx) > tol
    if target_side in {"top", "bottom"}:
        return abs(dx) <= tol and abs(dy) > tol
    return False


def _axis_segment_rect_clearance(p1, p2, rect):
    # Minimum Euclidean distance from an axis-aligned segment to a rectangle.
    x, y, w, h = rect
    x0, x1 = x, x+w
    y0, y1 = y, y+h
    ax, ay = p1; bx, by = p2
    if abs(ay-by) < 1e-9:  # horizontal
        sy = ay
        lo, hi = sorted([ax,bx])
        if hi >= x0 and lo <= x1:
            if y0 <= sy <= y1:
                return 0.0
            return min(abs(sy-y0), abs(sy-y1))
        dx = min(abs(lo-x1), abs(hi-x0))
        if y0 <= sy <= y1:
            return dx
        dy = min(abs(sy-y0), abs(sy-y1))
        return math.hypot(dx,dy)
    if abs(ax-bx) < 1e-9:  # vertical
        sx = ax
        lo, hi = sorted([ay,by])
        if hi >= y0 and lo <= y1:
            if x0 <= sx <= x1:
                return 0.0
            return min(abs(sx-x0), abs(sx-x1))
        dy = min(abs(lo-y1), abs(hi-y0))
        if x0 <= sx <= x1:
            return dy
        dx = min(abs(sx-x0), abs(sx-x1))
        return math.hypot(dx,dy)
    # Non-axis segments are not allowed in the publication connector grammar.
    return 0.0


def _font_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _data_to_pdf_point(x_mm, y_mm, page_rect):
    # Axes fill the final-size page: x maps directly; PDF y-axis is top-down.
    return fitz.Point(
        x_mm * page_rect.width / WIDTH_MM,
        (HEIGHT_MM - y_mm) * page_rect.height / HEIGHT_MM,
    )


def _pt_distance_mm(p1, p2):
    return math.hypot(p2.x-p1.x, p2.y-p1.y) * 25.4 / 72.0


def _rgb01(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i+2],16)/255.0 for i in (0,2,4))


def _color_close(a,b,tol=2e-3):
    if a is None or b is None:
        return False
    return all(abs(float(x)-float(y)) <= tol for x,y in zip(a,b))


def _pdf_terminal_measurement(page, expected_prev, expected_target, expected_color):
    prev_pdf = _data_to_pdf_point(*expected_prev, page.rect)
    target_pdf = _data_to_pdf_point(*expected_target, page.rect)
    best = None
    for di,d in enumerate(page.get_drawings()):
        if d.get("fill") is not None:
            continue
        if not _color_close(d.get("color"), expected_color):
            continue
        for ii,item in enumerate(d.get("items", [])):
            typ=item[0]
            if typ == "l":
                p0,p1=item[1],item[2]
            elif typ == "c":
                p0,p1=item[1],item[4]
            else:
                continue
            # Directed terminal is recognized by proximity to expected previous/target points.
            score=_pt_distance_mm(p0,prev_pdf)+_pt_distance_mm(p1,target_pdf)
            rev_score=_pt_distance_mm(p1,prev_pdf)+_pt_distance_mm(p0,target_pdf)
            if rev_score < score:
                p0,p1=p1,p0; score=rev_score
            rec={
                "drawing_index":di,"item_index":ii,"item_type":typ,
                "start_pt":[p0.x,p0.y],"end_pt":[p1.x,p1.y],
                "match_score_mm":score,"rendered_terminal_straight_mm":_pt_distance_mm(p0,p1),
                "stroke_width_pt":float(d.get("width") or 0.0),
            }
            if best is None or rec["match_score_mm"] < best["match_score_mm"]:
                best=rec
    if best is None or best["match_score_mm"] > 1.0:
        raise RuntimeError(f"PDF_TERMINAL_VECTOR_NOT_FOUND:{expected_prev}->{expected_target}:{best}")
    return best


def _pdf_find_panel(page, expected_rect_mm, expected_fill_hex):
    x,y,w,h=expected_rect_mm
    center_pdf=_data_to_pdf_point(x+w/2,y+h/2,page.rect)
    expected_fill=_rgb01(expected_fill_hex)
    candidates=[]
    for di,d in enumerate(page.get_drawings()):
        fill=d.get("fill")
        rect=d.get("rect")
        if rect is None or not _color_close(fill,expected_fill):
            continue
        if rect.contains(center_pdf):
            candidates.append((rect.get_area(),di,d))
    if not candidates:
        raise RuntimeError(f"PDF_PANEL_NOT_FOUND:{expected_rect_mm}:{expected_fill_hex}")
    _,di,d=min(candidates,key=lambda t:t[0])
    return {"drawing_index":di,"rect":d["rect"],"stroke_width_pt":float(d.get("width") or 0.0)}


def _distance_axis_segment_to_pdf_rect_mm(p1_mm,p2_mm,panel,page_rect,connector_width_pt):
    # Convert connector source data points to PDF pt and calculate physical ink-to-ink clearance.
    p1=_data_to_pdf_point(*p1_mm,page_rect); p2=_data_to_pdf_point(*p2_mm,page_rect)
    r=panel["rect"]
    # Centerline distance between axis-aligned segment and rendered panel path bounding rectangle.
    if abs(p1.y-p2.y) < 1e-6:  # horizontal
        lo,hi=sorted([p1.x,p2.x])
        if hi >= r.x0 and lo <= r.x1:
            center=max(0.0, max(r.y0-p1.y, p1.y-r.y1))
        else:
            dx=min(abs(lo-r.x1),abs(hi-r.x0))
            dy=0.0 if r.y0 <= p1.y <= r.y1 else min(abs(p1.y-r.y0),abs(p1.y-r.y1))
            center=math.hypot(dx,dy)
    elif abs(p1.x-p2.x) < 1e-6:  # vertical
        lo,hi=sorted([p1.y,p2.y])
        if hi >= r.y0 and lo <= r.y1:
            center=max(0.0, max(r.x0-p1.x, p1.x-r.x1))
        else:
            dy=min(abs(lo-r.y1),abs(hi-r.y0))
            dx=0.0 if r.x0 <= p1.x <= r.x1 else min(abs(p1.x-r.x0),abs(p1.x-r.x1))
            center=math.hypot(dx,dy)
    else:
        raise RuntimeError("NON_ORTHOGONAL_SEGMENT_IN_RENDERED_CLEARANCE_QA")
    physical_pt=max(0.0, center - connector_width_pt/2.0 - panel["stroke_width_pt"]/2.0)
    return {"centerline_clearance_mm":center*25.4/72.0,
            "stroke_to_stroke_clearance_mm":physical_pt*25.4/72.0}


def _svg_group_path_endpoints(svg_path, gid):
    # GID-tagged connector group; return straight-path first/last coordinates in SVG points.
    root=ET.parse(svg_path).getroot()
    ns={"svg":"http://www.w3.org/2000/svg"}
    group=None
    for g in root.iter('{http://www.w3.org/2000/svg}g'):
        if g.attrib.get('id') == gid:
            group=g; break
    if group is None:
        raise RuntimeError(f"SVG_GID_NOT_FOUND:{gid}")
    paths=list(group.iter('{http://www.w3.org/2000/svg}path'))
    candidates=[]
    num=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
    for p in paths:
        d=p.attrib.get('d','')
        vals=[float(x) for x in re.findall(num,d)]
        if len(vals) < 4: continue
        # For Matplotlib FancyArrowPatch terminal shaft, the first path starts M and ends at final C/L pair.
        x0,y0=vals[0],vals[1]; x1,y1=vals[-2],vals[-1]
        candidates.append({"d":d,"start_pt":[x0,y0],"end_pt":[x1,y1],
                           "length_mm":math.hypot(x1-x0,y1-y0)*25.4/72.0})
    if not candidates:
        raise RuntimeError(f"SVG_NO_PATH_GEOMETRY:{gid}")
    # Longest path in arrow group is the shaft; arrowhead is much shorter.
    return max(candidates,key=lambda x:x["length_mm"])


def _svg_association_arrowhead_absent(svg_path, gid):
    root=ET.parse(svg_path).getroot()
    group=None
    for g in root.iter('{http://www.w3.org/2000/svg}g'):
        if g.attrib.get('id') == gid:
            group=g; break
    if group is None:
        raise RuntimeError(f"SVG_ASSOCIATION_GID_NOT_FOUND:{gid}")
    paths=list(group.iter('{http://www.w3.org/2000/svg}path'))
    # A non-directional PathPatch association must emit exactly one unfilled path.
    styles=[p.attrib.get('style','') for p in paths]
    has_filled_geometry=any('fill: none' not in st and 'fill:none' not in st for st in styles)
    return {"gid":gid,"path_count":len(paths),"styles":styles,
            "arrowhead_absent": bool(len(paths)==1 and not has_filled_geometry)}


def _pdf_terminal_orientation(rec):
    x0,y0=rec["start_pt"]; x1,y1=rec["end_pt"]
    dx=abs(x1-x0); dy=abs(y1-y0)
    if dx < 1e-5 and dy > 1e-5: return "vertical"
    if dy < 1e-5 and dx > 1e-5: return "horizontal"
    return "other"


def _pdf_rendered_corner_clearance_mm(rec, panel, side):
    x,y=rec["end_pt"]
    r=panel["rect"]
    if side in {"left","right"}:
        return min(abs(y-r.y0),abs(r.y1-y))*25.4/72.0
    if side in {"top","bottom"}:
        return min(abs(x-r.x0),abs(r.x1-x))*25.4/72.0
    raise ValueError(side)


def _pdf_visible_terminal_to_outer_panel_stroke_mm(rec, panel, side):
    """Unoccluded terminal ink from last bend to exterior of later-drawn target-panel stroke."""
    sx, sy = rec["start_pt"]
    r = panel["rect"]
    half = panel["stroke_width_pt"] / 2.0
    if side == "left":
        outer = r.x0 - half
        dist_pt = outer - sx
    elif side == "right":
        outer = r.x1 + half
        dist_pt = sx - outer
    elif side == "top":
        outer = r.y0 - half
        dist_pt = outer - sy
    elif side == "bottom":
        outer = r.y1 + half
        dist_pt = sy - outer
    else:
        raise ValueError(side)
    return max(0.0, float(dist_pt)) * 25.4 / 72.0


def _svg_group_path_bbox(svg_path, gid):
    root = ET.parse(svg_path).getroot()
    group = None
    for g in root.iter('{http://www.w3.org/2000/svg}g'):
        if g.attrib.get('id') == gid:
            group = g
            break
    if group is None:
        raise RuntimeError(f"SVG_PANEL_GID_NOT_FOUND:{gid}")
    paths = list(group.iter('{http://www.w3.org/2000/svg}path'))
    if not paths:
        raise RuntimeError(f"SVG_PANEL_PATH_NOT_FOUND:{gid}")
    num = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
    xs=[]; ys=[]; stroke_widths=[]
    for p in paths:
        d=p.attrib.get('d','')
        vals=[float(x) for x in re.findall(num,d)]
        if len(vals) >= 2:
            xs.extend(vals[0::2]); ys.extend(vals[1::2])
        style=p.attrib.get('style','')
        m=re.search(r'stroke-width:\s*([0-9.]+)',style)
        if m:
            stroke_widths.append(float(m.group(1)))
    if not xs or not ys:
        raise RuntimeError(f"SVG_PANEL_NUMERIC_GEOMETRY_NOT_FOUND:{gid}")
    return {
        "bbox_pt":[min(xs),min(ys),max(xs),max(ys)],
        "stroke_width_pt":max(stroke_widths) if stroke_widths else 0.0,
    }


def _svg_visible_terminal_to_outer_panel_stroke_mm(terminal_rec, panel_rec, side):
    sx, sy = terminal_rec["start_pt"]
    x0,y0,x1,y1 = panel_rec["bbox_pt"]
    half = panel_rec["stroke_width_pt"]/2.0
    if side == "left":
        dist_pt = (x0-half) - sx
    elif side == "right":
        dist_pt = sx - (x1+half)
    elif side == "top":
        dist_pt = (y0-half) - sy
    elif side == "bottom":
        dist_pt = sy - (y1+half)
    else:
        raise ValueError(side)
    return max(0.0,float(dist_pt))*25.4/72.0


def render(outdir: Path) -> dict:
    global USED_FONT_SIZES, USED_LINE_WIDTHS, BOX_BINDINGS, PATCH_BINDINGS, FREE_TEXT_BINDINGS, CONNECTOR_ASSERTIONS, CONNECTOR_PATHS, ASSOCIATION_ASSERTIONS
    USED_FONT_SIZES = set()
    USED_LINE_WIDTHS = set()
    BOX_BINDINGS = []
    PATCH_BINDINGS = []
    FREE_TEXT_BINDINGS = []
    CONNECTOR_ASSERTIONS = []
    CONNECTOR_PATHS = []
    ASSOCIATION_ASSERTIONS = []

    outdir.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4), dpi=PNG_DPI)
    ax = fig.add_axes([0, 0, 1, 1])
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, WIDTH_MM)
    ax.set_ylim(0, HEIGHT_MM)
    ax.axis("off")

    # Header / relationship to Figure 1.
    add_free_text(ax, 5, 160.5, "MM local execution adapter | v1.0.6",
                  name="figure identifier header", fontsize=6.8, weight="bold", ha="left")
    add_free_text(ax, 175, 160.5,
                  "local implementation view of Figure 1 | non-normative | no runtime authorization",
                  name="figure relation header", fontsize=5.0, ha="right")

    # A. Host / virtualization boundary.
    header(ax, 5, 154.4, "Host and virtualization boundary")
    host_rect = (5.0, 132.0, 28.0, 16.0)
    wsl_rect = (38.0, 132.0, 48.0, 16.0)
    mnt_rect = (5.0, 115.2, 28.0, 12.0)
    add_box(ax, *host_rect,
            "WINDOWS HOST\nhost boundary",
            fontsize=5.3, weight="bold",
            facecolor=PALETTE["host_fill"], edgecolor=PALETTE["host_edge"],
            qa_name="Windows host")
    add_box(ax, *mnt_rect,
            "/mnt/c\nnot active scientific workspace\ninaccessible where required",
            fontsize=5.0, linestyle="--",
            facecolor=PALETTE["state_fill"], edgecolor=PALETTE["state_edge"],
            qa_name="mnt-c policy")
    add_box(ax, *wsl_rect,
            "WSL2 | Ubuntu 24.04.4 LTS\nx86_64 | systemd\nnative MM root: /opt/mm",
            fontsize=5.2, weight="bold",
            facecolor=PALETTE["host_fill"], edgecolor=PALETTE["host_edge"],
            qa_name="WSL2 platform")
    add_arrow(ax, host_rect[0] + host_rect[2], 140.0, wsl_rect[0], 140.0, lw=0.7)
    add_arrow(ax, 19.0, host_rect[1], 19.0, mnt_rect[1] + mnt_rect[3], lw=0.5, linestyle="--")

    # B. Actor separation. mm-a1/reviewer align with their sandboxes.
    header(ax, 91.0, 154.4, "Actor separation")
    admin_rect = (91.0, 132.0, 24.0, 16.0)
    a1_actor_rect = (118.0, 132.0, 27.0, 16.0)
    rev_actor_rect = (149.0, 132.0, 27.0, 16.0)
    add_box(ax, *admin_rect,
            "mmadmin | UID 1000\nbootstrap/admin only\nnot mutable scientific actor",
            fontsize=5.0,
            facecolor=PALETTE["admin_fill"], edgecolor=PALETTE["admin_edge"],
            qa_name="mmadmin actor")
    add_box(ax, *a1_actor_rect,
            "mm-a1 | UID 1001\nsole mutable execution actor\nno sudo/adm | caps=0",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["executor_fill"], edgecolor=PALETTE["executor_edge"],
            qa_name="mm-a1 actor")
    add_box(ax, *rev_actor_rect,
            "mm-review | UID 1003\nindependent read-only\nno output/scratch access",
            fontsize=5.0,
            facecolor=PALETTE["review_fill"], edgecolor=PALETTE["review_edge"],
            qa_name="reviewer actor")

    # C. Controlled filesystem authority model.
    header(ax, 5, 112.5, "Controlled filesystem authority model")
    fs_rect = (5.0, 73.0, 100.0, 32.5)
    add_box(ax, *fs_rect, "", rounded=False,
            facecolor="#FFFFFF", edgecolor=PALETTE["neutral_edge"], qa_name="filesystem container")
    fs_items = [
        ((7.3, 89.5, 17.0, 13.0), "input/\nroot-owned\nread-only authority",
         PALETTE["readonly_fill"], PALETTE["readonly_edge"], "-", "input surface"),
        ((26.6, 89.5, 17.0, 13.0), "review/\nroot-owned\nread-only evidence",
         PALETTE["readonly_fill"], PALETTE["readonly_edge"], "-", "review surface"),
        ((45.9, 89.5, 17.0, 13.0), "output/\nauthorized\nmutable output",
         PALETTE["mutable_fill"], PALETTE["mutable_edge"], "-", "output surface"),
        ((65.2, 89.5, 17.0, 13.0), "scratch/\nGate-controlled\nexecution state",
         PALETTE["mutable_fill"], PALETTE["mutable_edge"], "--", "scratch surface"),
        ((84.5, 89.5, 17.0, 13.0), "toolchain/\nroot-owned\nimmutable",
         PALETTE["toolchain_fill"], PALETTE["toolchain_edge"], "-", "toolchain surface"),
    ]
    for rect, txt, fc, ec, ls, name in fs_items:
        add_box(ax, *rect, txt, fontsize=5.0, facecolor=fc, edgecolor=ec,
                linestyle=ls, lw=0.55, qa_name=name)
    child_rect = (7.3, 72.5, 94.2, 10.8)
    add_box(ax, *child_rect, "", fontsize=5.0, linestyle="--",
            facecolor=PALETTE["state_fill"], edgecolor=PALETTE["state_edge"],
            qa_name="child command boundary")
    child_policy_rect = (8.5, 73.5, 60.5, 8.6)
    add_box(ax, *child_policy_rect,
            "CHILD COMMAND BOUNDARY\nRO: input/review | RW: output + primary Gate workspace\ninput/review/global scratch/auth/config/child AF_INET mutation denied",
            fontsize=5.0, rounded=False, lw=0.0,
            facecolor=PALETTE["state_fill"], edgecolor="none",
            qa_name="child command policy")
    workspace_rect = (72.0, 74.5, 27.5, 6.6)
    add_box(ax, *workspace_rect,
            "PRIMARY GATE WORKSPACE\nbounded within scratch/", fontsize=5.0, weight="bold",
            linestyle="--", facecolor=PALETTE["mutable_fill"], edgecolor=PALETTE["mutable_edge"],
            qa_name="primary Gate workspace")
    # Visually bind workspace to the Gate-controlled scratch concept without granting global scratch access.
    scratch_rect = fs_items[3][0]
    add_line(ax, scratch_rect[0] + scratch_rect[2]/2, scratch_rect[1],
             workspace_rect[0] + workspace_rect[2]/2, workspace_rect[1] + workspace_rect[3],
             lw=0.45, linestyle="--", color=PALETTE["mutable_edge"])

    # D. Sandbox / least-privilege controls.
    header(ax, 113.0, 114.0, "Sandbox and least privilege")
    a1_sandbox_rect = (118.0, 88.0, 27.0, 18.0)
    rev_sandbox_rect = (149.0, 88.0, 26.0, 18.0)
    harness_rect = (113.0, 72.0, 63.0, 11.2)
    add_box(ax, *a1_sandbox_rect,
            "A1 transient unit\nProtectSystem=strict\nProtectHome=yes\nNoNewPrivileges=yes\nRestrictSUIDSGID=yes",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["executor_fill"], edgecolor=PALETTE["executor_edge"],
            qa_name="A1 sandbox")
    add_box(ax, *rev_sandbox_rect,
            "Reviewer transient unit\ninput/review readable\noutput/scratch unusable\n/mnt/c inaccessible\nloopback-only view",
            fontsize=5.0,
            facecolor=PALETTE["review_fill"], edgecolor=PALETTE["review_edge"],
            qa_name="Reviewer sandbox")
    add_box(ax, *harness_rect,
            "HARNESS CONTROLS\nMAX_ATTEMPTS=1 | automatic retry=false\nresource/side-effect bounds | independent readback | STOP=true",
            fontsize=5.0, linestyle="--",
            facecolor=PALETTE["neutral_fill"], edgecolor=PALETTE["neutral_edge"],
            qa_name="Harness controls")

    # Identity bindings use non-directional association grammar, not access-flow arrows.
    a1_start = (a1_actor_rect[0] + a1_actor_rect[2] / 2, a1_actor_rect[1])
    a1_end = (a1_sandbox_rect[0], 99.0)  # left-edge identity port, >3 mm from rounded corners
    a1_actor_points = [a1_start, (a1_start[0],118.0), (110.0,118.0), (110.0,99.0), a1_end]
    add_poly_association(ax, a1_actor_points, lw=0.60, color=PALETTE["executor_edge"],
                         label="execution identity", label_xy=(121.5,121.0), label_size=5.0,
                         label_allowed_patches={"mm-a1 actor","A1 sandbox"}, connector_id="execution-identity")
    ASSOCIATION_ASSERTIONS.append({
        "name":"mm-a1 execution identity", "points":a1_actor_points,
        "source":a1_actor_rect, "target":a1_sandbox_rect,
        "source_name":"mm-a1 actor", "target_name":"A1 sandbox",
        "arrowhead":False, "target_side":"left"
    })
    CONNECTOR_PATHS.append({"name":"mm-a1 execution identity", "points":a1_actor_points,
                            "label_name":"association label:execution identity",
                            "allowed_patches":{"mm-a1 actor","A1 sandbox"}})

    rev_start = (rev_actor_rect[0] + rev_actor_rect[2] / 2, rev_actor_rect[1])
    rev_end = (rev_sandbox_rect[0] + rev_sandbox_rect[2], 99.0)  # right-edge identity port
    rev_actor_points = [rev_start, (rev_start[0],118.0), (178.0,118.0), (178.0,99.0), rev_end]
    add_poly_association(ax, rev_actor_points, lw=0.60, color=PALETTE["review_edge"],
                         label="review identity", label_xy=(162.0,121.0), label_size=5.0,
                         label_allowed_patches={"reviewer actor","Reviewer sandbox"}, connector_id="review-identity")
    ASSOCIATION_ASSERTIONS.append({
        "name":"mm-review review identity", "points":rev_actor_points,
        "source":rev_actor_rect, "target":rev_sandbox_rect,
        "source_name":"reviewer actor", "target_name":"Reviewer sandbox",
        "arrowhead":False, "target_side":"right"
    })
    CONNECTOR_PATHS.append({"name":"mm-review review identity", "points":rev_actor_points,
                            "label_name":"association label:review identity",
                            "allowed_patches":{"reviewer actor","Reviewer sandbox"}})

    # Typed filesystem ports / exact permitted access edges.
    input_rect = fs_items[0][0]
    review_rect = fs_items[1][0]
    output_rect = fs_items[2][0]

    # READ input -> A1 sandbox. Dedicated upper routing lane; final segment enters left edge normally.
    input_read_start = (input_rect[0] + input_rect[2]/2, input_rect[1] + input_rect[3])
    input_read_target = (a1_sandbox_rect[0], 103.0)
    input_read_points = [input_read_start, (input_read_start[0],108.0), (110.5,108.0),
                         (110.5,input_read_target[1]), input_read_target]
    add_poly_arrow(ax, input_read_points, lw=0.50, color=PALETTE["readonly_edge"],
                   label="read input", label_xy=(16.0,110.5), label_size=5.0, connector_id="read-input")
    CONNECTOR_ASSERTIONS.append({
        "name":"read input", "start":input_read_start, "end":input_read_target,
        "source":input_rect, "target":a1_sandbox_rect,
        "source_name":"input surface", "target_name":"A1 sandbox",
        "relation_type":"access", "arrowhead":True, "target_side":"left",
        "label_name":"connector label:read input"
    })
    CONNECTOR_PATHS.append({"name":"read input", "points":input_read_points,
                            "label_name":"connector label:read input",
                            "allowed_patches":{"input surface","filesystem container","A1 sandbox"}})

    # READ review -> A1 sandbox. Separate lower read lane with >=1.5 mm separation.
    review_read_start = (review_rect[0] + review_rect[2]/2, review_rect[1] + review_rect[3])
    review_read_target = (a1_sandbox_rect[0], 98.0)
    review_read_points = [review_read_start, (review_read_start[0],106.5), (110.5,106.5),
                          (110.5,review_read_target[1]), review_read_target]
    add_poly_arrow(ax, review_read_points, lw=0.50, color=PALETTE["readonly_edge"],
                   label="read review", label_xy=(36.0,104.0), label_size=5.0,
                   label_allowed_patches={"filesystem container"}, connector_id="read-review")
    CONNECTOR_ASSERTIONS.append({
        "name":"read review", "start":review_read_start, "end":review_read_target,
        "source":review_rect, "target":a1_sandbox_rect,
        "source_name":"review surface", "target_name":"A1 sandbox",
        "relation_type":"access", "arrowhead":True, "target_side":"left",
        "label_name":"connector label:read review"
    })
    CONNECTOR_PATHS.append({"name":"read review", "points":review_read_points,
                            "label_name":"connector label:read review",
                            "allowed_patches":{"review surface","filesystem container","A1 sandbox"}})

    # WRITE A1 sandbox -> output/. Lower corridor creates >=3 mm terminal vertical segment.
    output_target = (output_rect[0] + output_rect[2]/2, output_rect[1])
    write_output_points = [(a1_sandbox_rect[0],96.0), (103.5,96.0), (103.5,84.0),
                           (output_target[0],84.0), output_target]
    add_poly_arrow(ax, write_output_points, lw=0.55, color=PALETTE["mutable_edge"],
                   label="write", label_xy=(114.0,94.0), label_size=5.0,
                   label_allowed_patches={"filesystem container"}, connector_id="write-output")
    CONNECTOR_ASSERTIONS.append({
        "name":"write output", "start":write_output_points[0], "end":output_target,
        "source":a1_sandbox_rect, "target":output_rect,
        "source_name":"A1 sandbox", "target_name":"output surface",
        "relation_type":"access", "arrowhead":True, "target_side":"bottom",
        "label_name":"connector label:write"
    })
    CONNECTOR_PATHS.append({"name":"write output", "points":write_output_points,
                            "label_name":"connector label:write",
                            "allowed_patches":{"A1 sandbox","filesystem container","output surface"}})

    # WRITE A1 sandbox -> primary Gate workspace. Route outside harness left edge.
    workspace_target = (workspace_rect[0] + workspace_rect[2], workspace_rect[1] + workspace_rect[3]/2)
    write_ws_points = [(a1_sandbox_rect[0],91.5), (110.0,91.5), (110.0,workspace_target[1]), workspace_target]
    add_poly_arrow(ax, write_ws_points, lw=0.55, color=PALETTE["mutable_edge"],
                   label="write WS", label_xy=(111.0,89.5), label_size=5.0, connector_id="write-workspace",
                   label_allowed_patches={"filesystem container","child command boundary"})
    CONNECTOR_ASSERTIONS.append({
        "name":"write primary Gate workspace", "start":write_ws_points[0], "end":workspace_target,
        "source":a1_sandbox_rect, "target":workspace_rect,
        "source_name":"A1 sandbox", "target_name":"primary Gate workspace",
        "relation_type":"access", "arrowhead":True, "target_side":"right",
        "label_name":"connector label:write WS"
    })
    CONNECTOR_PATHS.append({"name":"write primary Gate workspace", "points":write_ws_points,
                            "label_name":"connector label:write WS",
                            "allowed_patches":{"A1 sandbox","filesystem container","child command boundary","primary Gate workspace"}})

    # EVIDENCE READ review/ -> reviewer sandbox.
    # v1.0.5 routes around the right side rather than through the A1/Reviewer inter-panel gap.
    # The final segment enters the Reviewer right edge normally with a 3.5 mm nominal approach.
    evidence_start = (review_rect[0] + review_rect[2]/2, review_rect[1])
    evidence_target = (rev_sandbox_rect[0] + rev_sandbox_rect[2], 96.0)
    evidence_outer_x = 179.5
    evidence_lane_y = 86.0
    evidence_points = [evidence_start, (evidence_start[0],evidence_lane_y),
                       (evidence_outer_x,evidence_lane_y),
                       (evidence_outer_x,evidence_target[1]), evidence_target]
    add_poly_arrow(ax, evidence_points, lw=0.55, color=PALETTE["review_edge"],
                   label="evidence read", label_xy=(151.0,evidence_lane_y), label_size=5.0,
                   label_allowed_patches={"filesystem container"}, connector_id="evidence-read")
    CONNECTOR_ASSERTIONS.append({
        "name":"review evidence read", "start":evidence_start, "end":evidence_target,
        "source":review_rect, "target":rev_sandbox_rect,
        "source_name":"review surface", "target_name":"Reviewer sandbox",
        "relation_type":"access", "arrowhead":True, "target_side":"right",
        "label_name":"connector label:evidence read"
    })
    CONNECTOR_PATHS.append({"name":"review evidence read", "points":evidence_points,
                            "label_name":"connector label:evidence read",
                            "allowed_patches":{"review surface","filesystem container","Reviewer sandbox"}})

    # Explicit read-lane separation is a publication requirement, not incidental geometry.
    read_lane_separation_mm = abs(108.0 - 106.5)
    if read_lane_separation_mm < MIN_PARALLEL_LANE_SEPARATION_MM - 1e-9:
        raise RuntimeError(f"READ_LANE_SEPARATION_FAILED:{read_lane_separation_mm}")

    # E. Toolchain / credential / network boundary.
    header(ax, 5, 66.5, "Controlled toolchain, credentials and network boundary")
    tool_rect = (5.0, 49.0, 47.0, 13.0)
    cred_rect = (55.0, 49.0, 53.0, 13.0)
    net_rect = (113.0, 49.0, 63.0, 13.0)
    add_box(ax, *tool_rect,
            "Codex standalone 0.153.4\nroot-owned / read-only\nproject toolchain\nentrypoint identity frozen",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["toolchain_fill"], edgecolor=PALETTE["toolchain_edge"],
            qa_name="controlled toolchain")
    add_box(ax, *cred_rect,
            "Operational CODEX_HOME / credentials\nauthentication separate from immutable toolchain\nauth.json / config.toml protected",
            fontsize=5.0,
            facecolor=PALETTE["neutral_fill"], edgecolor=PALETTE["neutral_edge"],
            qa_name="credential boundary")
    add_box(ax, *net_rect,
            "Client / command network separation\nclient connectivity may be authorized per Gate\nchild-command network capability remains separately constrained",
            fontsize=5.0,
            facecolor=PALETTE["neutral_fill"], edgecolor=PALETTE["neutral_edge"],
            qa_name="network boundary")

    # F. Current qualification / unresolved execution-plane state.
    header(ax, 5, 43.0, "Current qualification boundary")
    qualified_rect = (5.0, 27.0, 50.0, 12.0)
    m4_rect = (59.0, 27.0, 55.0, 12.0)
    m4r1_rect = (118.0, 27.0, 58.0, 12.0)
    add_box(ax, *qualified_rect,
            "LOCAL ADAPTER BOUNDARY\nQUALIFIED\nOS | actor | filesystem\nsandbox controls demonstrated",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["executor_fill"], edgecolor=PALETTE["executor_edge"],
            qa_name="qualified adapter state")
    add_box(ax, *m4_rect,
            "M4 BEHAVIORAL QUALIFICATION\nNOT ESTABLISHED\nHOLD_INFRASTRUCTURE_PREMODEL\n0 confirmed model turns",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["hold_fill"], edgecolor=PALETTE["hold_edge"],
            qa_name="M4 state")
    add_box(ax, *m4r1_rect,
            "M4R1 PROSPECTIVE REMEDIATION\nHOLD F03\nstaged-terminal readiness\ncausal-cycle design finding",
            fontsize=5.0, weight="bold",
            facecolor=PALETTE["hold_fill"], edgecolor=PALETTE["hold_edge"],
            qa_name="M4R1 state")

    # ASCII-safe critical boundary to prevent semantic glyph substitution.
    runtime_rect = (5.0, 8.0, 171.0, 14.0)
    add_box(ax, *runtime_rect, "", rounded=False, lw=0.8,
            facecolor=PALETTE["state_fill"], edgecolor=PALETTE["state_edge"],
            qa_name="runtime boundary panel")
    add_free_text(ax, 90.5, 18.1, RUNTIME_BOUNDARY_TEXT,
                  name="runtime boundary statement", fontsize=6.0, weight="bold",
                  allowed_patches={"runtime boundary panel"})
    runtime = [
        "scientific runtime = false",
        "GEE runtime = false",
        "production runtime = false",
        "M4 rerun authorized = false",
    ]
    xs = [11.5, 53.5, 95.5, 137.5]
    for x, label in zip(xs, runtime):
        add_box(ax, x, 9.3, 34.0, 5.2, label,
                fontsize=5.0, linestyle="--", lw=0.5,
                facecolor="#FFFFFF", edgecolor=PALETTE["state_edge"],
                qa_name=f"runtime label {label}")

    add_free_text(ax, 176.0, 3.8, f"{FIGURE_ID} v{VERSION}",
                  name="figure footer identifier", fontsize=5.0, ha="right")

    # Mechanical layout QA before export.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    px_per_mm = fig.dpi / 25.4
    text_fit = []
    for item in BOX_BINDINGS:
        tb = item["text"].get_window_extent(renderer=renderer)
        pb = item["patch"].get_window_extent(renderer=renderer)
        margin = item["margin_mm"] * px_per_mm
        ok = (tb.x0 >= pb.x0 + margin and tb.x1 <= pb.x1 - margin and
              tb.y0 >= pb.y0 + margin and tb.y1 <= pb.y1 - margin)
        text_fit.append({
            "name": item["name"], "pass": bool(ok),
            "text_bbox_px": [tb.x0, tb.y0, tb.x1, tb.y1],
            "box_bbox_px": [pb.x0, pb.y0, pb.x1, pb.y1],
            "margin_mm": item["margin_mm"],
        })
    failed_fit = [x for x in text_fit if not x["pass"]]
    if failed_fit:
        raise RuntimeError("TEXT_FIT_QA_FAILED: " + json.dumps(failed_fit, ensure_ascii=False))

    connector_checks = []
    for c in CONNECTOR_ASSERTIONS:
        start_ok = _point_on_rect_boundary(c["start"][0], c["start"][1], c["source"])
        end_ok = _point_on_rect_boundary(c["end"][0], c["end"][1], c["target"])
        connector_checks.append({
            "name": c["name"], "source_name": c.get("source_name"), "target_name": c.get("target_name"),
            "start_on_source": start_ok, "end_on_target": end_ok
        })
    failed_connectors = [c for c in connector_checks if not (c["start_on_source"] and c["end_on_target"])]
    if failed_connectors:
        raise RuntimeError("CONNECTOR_ENDPOINT_QA_FAILED: " + json.dumps(failed_connectors))

    # Derived endpoint-assurance indicators: never hard-code observations in the receipt.
    # Generic filesystem-parent usage means a material connector starts or ends on the
    # outer filesystem container boundary rather than its exact typed source/target.
    generic_fs_endpoint_usage = any(
        _point_on_rect_boundary(c["start"][0], c["start"][1], fs_rect)
        or _point_on_rect_boundary(c["end"][0], c["end"][1], fs_rect)
        for c in CONNECTOR_ASSERTIONS
    )
    material_arrow_whitespace_endpoints = sum(
        1 for c in connector_checks
        if not (c["start_on_source"] and c["end_on_target"])
    )
    if generic_fs_endpoint_usage:
        raise RuntimeError("GENERIC_FILESYSTEM_ENDPOINT_USAGE_DETECTED")
    if material_arrow_whitespace_endpoints != 0:
        raise RuntimeError("MATERIAL_ARROW_WHITESPACE_ENDPOINT_DETECTED")

    # Connector microgeometry QA: access arrows require precise ports and terminal geometry;
    # identity associations are non-directional and must never carry arrowheads.
    association_checks = []
    for a in ASSOCIATION_ASSERTIONS:
        start_ok = _point_on_rect_boundary(a["points"][0][0], a["points"][0][1], a["source"])
        end_ok = _point_on_rect_boundary(a["points"][-1][0], a["points"][-1][1], a["target"])
        target_side = _boundary_side(a["points"][-1], a["target"])
        association_checks.append({
            "name":a["name"], "start_on_source":start_ok, "end_on_target":end_ok,
            "target_side":target_side, "arrowhead":a["arrowhead"],
            "corner_clearance_mm":_corner_clearance_mm(a["points"][-1], a["target"], a["target_side"]),
            "pass": bool(start_ok and end_ok and not a["arrowhead"] and a["target_side"] in target_side)
        })
    if not all(x["pass"] for x in association_checks):
        raise RuntimeError("IDENTITY_ASSOCIATION_QA_FAILED:" + json.dumps(association_checks))

    access_microgeometry = []
    path_by_name = {c["name"]:c for c in CONNECTOR_PATHS}
    for c in CONNECTOR_ASSERTIONS:
        if c.get("relation_type") != "access":
            continue
        path = path_by_name[c["name"]]["points"]
        side = c["target_side"]
        sides_seen = _boundary_side(path[-1], c["target"])
        corner_clearance = _corner_clearance_mm(path[-1], c["target"], side)
        terminal_length = _segment_length_mm(path[-2], path[-1])
        perpendicular = _perpendicular_incidence(path, side)
        access_microgeometry.append({
            "name":c["name"], "target_side":side, "sides_seen":sides_seen,
            "corner_clearance_mm":corner_clearance,
            "terminal_straight_mm":terminal_length,
            "perpendicular_incidence":perpendicular,
            "arrowhead":c.get("arrowhead",False),
            "pass": bool(
                side in sides_seen
                and corner_clearance >= MIN_ENDPOINT_CORNER_CLEARANCE_MM - 1e-9
                and terminal_length >= MIN_TERMINAL_STRAIGHT_MM - 1e-9
                and perpendicular
                and c.get("arrowhead",False)
            )
        })
    if not all(x["pass"] for x in access_microgeometry):
        raise RuntimeError("ACCESS_MICROGEOMETRY_QA_FAILED:" + json.dumps(access_microgeometry))

    # Cross-object collision matrix. Text may overlap only its own box, an intentional
    # containing parent box, or an explicitly allowlisted patch for free-standing text.
    patch_by_name = {p["name"]: p for p in PATCH_BINDINGS}
    cross_collisions = []
    collision_clearance_px = 0.12 * px_per_mm
    for item in BOX_BINDINGS:
        tb = item["text"].get_window_extent(renderer=renderer)
        own = patch_by_name[item["patch_name"]]
        own_rect = own["rect"]
        for p in PATCH_BINDINGS:
            if p["name"] == item["patch_name"]:
                continue
            # Parent containers intentionally contain child text/boxes.
            if _rect_contains_rect(p["rect"], own_rect):
                continue
            pb = p["patch"].get_window_extent(renderer=renderer)
            if _bbox_overlap(tb, pb, tol_px=collision_clearance_px):
                cross_collisions.append({"text": item["name"], "unrelated_patch": p["name"]})
    for item in FREE_TEXT_BINDINGS:
        tb = item["text"].get_window_extent(renderer=renderer)
        for p in PATCH_BINDINGS:
            if p["name"] in item["allowed_patches"]:
                continue
            pb = p["patch"].get_window_extent(renderer=renderer)
            if _bbox_overlap(tb, pb, tol_px=collision_clearance_px):
                cross_collisions.append({"text": item["name"], "unrelated_patch": p["name"]})
    free_text_collisions = []
    free_bboxes = [(item["name"], item["text"].get_window_extent(renderer=renderer)) for item in FREE_TEXT_BINDINGS]
    for i, (n1, b1) in enumerate(free_bboxes):
        for n2, b2 in free_bboxes[i+1:]:
            if _bbox_overlap(b1, b2, tol_px=collision_clearance_px):
                free_text_collisions.append({"text_a": n1, "text_b": n2})
    if cross_collisions or free_text_collisions:
        raise RuntimeError("CROSS_OBJECT_COLLISION_QA_FAILED: " + json.dumps({"text_patch": cross_collisions, "text_text": free_text_collisions}, ensure_ascii=False))

    # Connector body must not traverse unrelated leaf boxes or unrelated free-standing text.
    # their child ports are explicitly allowlisted per connector.
    connector_body_collisions = []
    for c in CONNECTOR_PATHS:
        allowed = set(c.get("allowed_patches", set()))
        pts = c["points"]
        for p in PATCH_BINDINGS:
            if p["name"] in allowed:
                continue
            # Skip broad parent containers; endpoint semantics are checked separately.
            if p["name"] in {"filesystem container", "child command boundary", "runtime boundary panel"}:
                continue
            for p1, p2 in zip(pts[:-1], pts[1:]):
                if _segment_intersects_rect_interior(p1, p2, p["rect"]):
                    connector_body_collisions.append({"connector": c["name"], "patch": p["name"]})
                    break
    inv = ax.transData.inverted()
    free_text_data_rects = []
    for item in FREE_TEXT_BINDINGS:
        bb = item["text"].get_window_extent(renderer=renderer)
        (x0,y0) = inv.transform((bb.x0, bb.y0)); (x1,y1) = inv.transform((bb.x1, bb.y1))
        free_text_data_rects.append((item["name"], (x0,y0,x1-x0,y1-y0)))
    # Publication clearances: material connector segments must remain separated from
    # unrelated text and unrelated leaf panels even when they do not geometrically intersect.
    connector_clearance_checks = []
    for c in CONNECTOR_PATHS:
        allowed = set(c.get("allowed_patches", set()))
        own_label = c.get("label_name")
        min_text_clearance = float("inf")
        min_panel_clearance = float("inf")
        min_text_name = None
        min_panel_name = None
        for p1,p2 in zip(c["points"][:-1], c["points"][1:]):
            for name, rect in free_text_data_rects:
                if name == own_label:
                    continue
                d = _axis_segment_rect_clearance(p1,p2,rect)
                if d < min_text_clearance:
                    min_text_clearance = d
                    min_text_name = name
            for p in PATCH_BINDINGS:
                if p["name"] in allowed:
                    continue
                if p["name"] in {"filesystem container","child command boundary","runtime boundary panel"}:
                    continue
                d = _axis_segment_rect_clearance(p1,p2,p["rect"])
                if d < min_panel_clearance:
                    min_panel_clearance = d
                    min_panel_name = p["name"]
        connector_clearance_checks.append({
            "name":c["name"],
            "min_unrelated_text_clearance_mm": None if min_text_clearance == float("inf") else min_text_clearance,
            "limiting_unrelated_text": min_text_name,
            "min_unrelated_panel_clearance_mm": None if min_panel_clearance == float("inf") else min_panel_clearance,
            "limiting_unrelated_panel": min_panel_name,
            "text_clearance_pass": bool(min_text_clearance == float("inf") or min_text_clearance >= MIN_CONNECTOR_TEXT_CLEARANCE_MM - 1e-9),
            "panel_clearance_pass": bool(min_panel_clearance == float("inf") or min_panel_clearance >= MIN_CONNECTOR_PANEL_CLEARANCE_MM - 1e-9),
        })
    failed_clearance = [x for x in connector_clearance_checks
                        if not (x["text_clearance_pass"] and x["panel_clearance_pass"])]
    if failed_clearance:
        raise RuntimeError("CONNECTOR_CLEARANCE_QA_FAILED:" + json.dumps(failed_clearance))

    connector_text_collisions = []
    for c in CONNECTOR_PATHS:
        own_label = c.get("label_name")
        for name, rect in free_text_data_rects:
            if name == own_label:
                continue
            for p1,p2 in zip(c["points"][:-1], c["points"][1:]):
                if _segment_intersects_rect_interior(p1,p2,rect,tol=0.01):
                    connector_text_collisions.append({"connector":c["name"],"text":name})
                    break
    if connector_body_collisions or connector_text_collisions:
        raise RuntimeError("CONNECTOR_BODY_COLLISION_QA_FAILED: " + json.dumps({"patch":connector_body_collisions,"text":connector_text_collisions}, ensure_ascii=False))

    negative_fixtures = _run_negative_fixtures()
    if not all(x["detected"] for x in negative_fixtures):
        raise RuntimeError("NEGATIVE_FIXTURE_QA_FAILED: " + json.dumps(negative_fixtures))

    # Export. Exact same font family and geometry used for all formats.
    svg_path = outdir / "mm-local-execution-adapter-v1.0.6.svg"
    pdf_path = outdir / "mm-local-execution-adapter-v1.0.6.pdf"
    png_path = outdir / "mm-local-execution-adapter-v1.0.6.png"
    fixed_dt = _dt.datetime(2026, 11, 11, 0, 0, 0, tzinfo=_dt.timezone.utc)
    fig.savefig(svg_path, format="svg", metadata={
        "Title": TITLE,
        "Creator": "MM deterministic Python/Matplotlib figure generator",
        "Description": "Non-normative local implementation derivative; certified MM authorities control.",
        "Date": "2026-11-11",
    })
    fig.savefig(pdf_path, format="pdf", metadata={
        "Title": TITLE,
        "Author": "MM deterministic Python/Matplotlib figure generator",
        "Subject": "Non-normative local implementation derivative; certified MM authorities control.",
        "CreationDate": fixed_dt,
        "ModDate": fixed_dt,
        "Producer": "MM deterministic Python/Matplotlib figure generator",
    })
    fig.savefig(png_path, format="png", dpi=PNG_DPI, metadata={
        "Software": "MM deterministic Python/Matplotlib figure generator",
        "Title": TITLE,
    })
    plt.close(fig)

    # Rendered-vector QA is dispositive for publication geometry.
    pdf_doc = fitz.open(pdf_path)
    pdf_page = pdf_doc[0]
    pdf_colors = {
        "readonly": _rgb01(PALETTE["readonly_edge"]),
        "mutable": _rgb01(PALETTE["mutable_edge"]),
        "review": _rgb01(PALETTE["review_edge"]),
    }
    rendered_specs = {
        "read input": {"points":input_read_points,"color":pdf_colors["readonly"],"gid":"terminal-read-input","target_rect":a1_sandbox_rect,"target_fill":PALETTE["executor_fill"],"target_side":"left","target_gid":"panel-a1-sandbox"},
        "read review": {"points":review_read_points,"color":pdf_colors["readonly"],"gid":"terminal-read-review","target_rect":a1_sandbox_rect,"target_fill":PALETTE["executor_fill"],"target_side":"left","target_gid":"panel-a1-sandbox"},
        "write output": {"points":write_output_points,"color":pdf_colors["mutable"],"gid":"terminal-write-output","target_rect":output_rect,"target_fill":PALETTE["mutable_fill"],"target_side":"bottom","target_gid":"panel-output-surface"},
        "write primary Gate workspace": {"points":write_ws_points,"color":pdf_colors["mutable"],"gid":"terminal-write-workspace","target_rect":workspace_rect,"target_fill":PALETTE["mutable_fill"],"target_side":"right","target_gid":"panel-primary-gate-workspace"},
        "review evidence read": {"points":evidence_points,"color":pdf_colors["review"],"gid":"terminal-evidence-read","target_rect":rev_sandbox_rect,"target_fill":PALETTE["review_fill"],"target_side":"right","target_gid":"panel-reviewer-sandbox"},
    }
    rendered_access = {}
    for name,spec in rendered_specs.items():
        pdf_rec=_pdf_terminal_measurement(pdf_page,spec["points"][-2],spec["points"][-1],spec["color"])
        panel=_pdf_find_panel(pdf_page,spec["target_rect"],spec["target_fill"])
        svg_rec=_svg_group_path_endpoints(svg_path,spec["gid"])
        svg_panel=_svg_group_path_bbox(svg_path,spec["target_gid"])
        orientation=_pdf_terminal_orientation(pdf_rec)
        expected_orientation="horizontal" if spec["target_side"] in {"left","right"} else "vertical"
        pdf_visible=_pdf_visible_terminal_to_outer_panel_stroke_mm(pdf_rec,panel,spec["target_side"])
        svg_visible=_svg_visible_terminal_to_outer_panel_stroke_mm(svg_rec,svg_panel,spec["target_side"])
        rendered_access[name]={
            "nominal_source_terminal_mm":_segment_length_mm(spec["points"][-2],spec["points"][-1]),
            "target_side":spec["target_side"],
            "pdf":pdf_rec,
            "svg":svg_rec,
            "svg_target_panel":svg_panel,
            "pdf_visible_terminal_to_outer_panel_stroke_mm":pdf_visible,
            "svg_visible_terminal_to_outer_panel_stroke_mm":svg_visible,
            "pdf_rendered_corner_clearance_mm":_pdf_rendered_corner_clearance_mm(pdf_rec,panel,spec["target_side"]),
            "pdf_terminal_orientation":orientation,
            "perpendicular_incidence_pass":orientation==expected_orientation,
        }
        rendered_access[name]["pass"]=bool(
            pdf_rec["rendered_terminal_straight_mm"] >= MIN_TERMINAL_STRAIGHT_MM - 1e-6
            and svg_rec["length_mm"] >= MIN_TERMINAL_STRAIGHT_MM - 1e-6
            and pdf_visible >= LOCAL_VISIBLE_TERMINAL_TARGET_MM - 1e-6
            and svg_visible >= LOCAL_VISIBLE_TERMINAL_TARGET_MM - 1e-6
            and rendered_access[name]["pdf_rendered_corner_clearance_mm"] >= MIN_ENDPOINT_CORNER_CLEARANCE_MM - 1e-6
            and rendered_access[name]["perpendicular_incidence_pass"]
        )

    pdf_a1_panel = _pdf_find_panel(pdf_page, a1_sandbox_rect, PALETTE["executor_fill"])
    evidence_to_a1_segments = []
    evidence_connector_width_pt = 0.55
    for p1,p2 in zip(evidence_points[:-1], evidence_points[1:]):
        m = _distance_axis_segment_to_pdf_rect_mm(
            p1,p2,pdf_a1_panel,pdf_page.rect,evidence_connector_width_pt)
        evidence_to_a1_segments.append({"segment":[list(p1),list(p2)], **m})
    rendered_evidence_to_a1_clearance_mm = min(
        x["stroke_to_stroke_clearance_mm"] for x in evidence_to_a1_segments)
    pdf_doc.close()

    rendered_identity = {
        "execution identity": _svg_association_arrowhead_absent(svg_path,"association-execution-identity"),
        "review identity": _svg_association_arrowhead_absent(svg_path,"association-review-identity"),
    }

    rendered_vector_qa = {
        "source_geometry": {
            "write_output_terminal_nominal_mm": _segment_length_mm(write_output_points[-2],write_output_points[-1]),
            "evidence_read_terminal_nominal_mm": _segment_length_mm(evidence_points[-2],evidence_points[-1]),
            "evidence_target_side": "right",
            "evidence_corner_clearance_nominal_mm": _corner_clearance_mm(evidence_target,rev_sandbox_rect,"right"),
        },
        "rendered_access_flows": rendered_access,
        "rendered_identity_associations": rendered_identity,
        "pdf_evidence_to_a1_segments": evidence_to_a1_segments,
        "pdf_evidence_to_a1_min_stroke_clearance_mm": rendered_evidence_to_a1_clearance_mm,
        "pass": bool(
            all(v["pass"] for v in rendered_access.values())
            and all(v["arrowhead_absent"] for v in rendered_identity.values())
            and rendered_evidence_to_a1_clearance_mm >= MIN_CONNECTOR_PANEL_CLEARANCE_MM - 1e-6
        ),
    }
    if not rendered_vector_qa["pass"]:
        raise RuntimeError("RENDERED_VECTOR_GEOMETRY_QA_FAILED:" + json.dumps(rendered_vector_qa, ensure_ascii=False))

    def sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    svg = svg_path.read_text(encoding="utf-8")
    width_match = re.search(r'width="([0-9.]+)pt"', svg)
    height_match = re.search(r'height="([0-9.]+)pt"', svg)
    width_pt = float(width_match.group(1)) if width_match else None
    height_pt = float(height_match.group(1)) if height_match else None
    pt_to_mm = 25.4 / 72.0

    manifest = {
        "figure_id": FIGURE_ID,
        "version": VERSION,
        "title": TITLE,
        "generator": "Python + Matplotlib",
        "generative_ai_image_used": False,
        "relationship_to_figure_1": "implementation adapter view subordinate to system-level development architecture",
        "publication_font": {
            "family": FONT_FAMILY,
            "resolved_file_name": FONT_PATH.name,
            "resolved_file_sha256": _font_sha256(FONT_PATH),
            "pdf_fonttype": 42,
            "pdf_use14corefonts": False,
            "font_file_distributed": False,
        },
        "nature_profile": {
            "target_width_mm": WIDTH_MM,
            "target_height_mm": HEIGHT_MM,
            "standard_label_font_pt_min": FONT_MIN_PT,
            "standard_label_font_pt_max": FONT_MAX_PT,
            "png_dpi": PNG_DPI,
        },
        "colour_accessibility": {
            "rgb": True,
            "red_green_semantic_dependence": False,
            "rainbow_scale_used": False,
            "colour_is_redundant_grouping_cue": True,
            "black_text_on_light_fills": True,
            "palette": PALETTE,
        },
        "generator_observed": {
            "used_font_sizes_pt": sorted(USED_FONT_SIZES),
            "used_line_widths_pt": sorted(USED_LINE_WIDTHS),
        },
        "mechanical_layout_qa": {
            "text_fit_checks": text_fit,
            "text_fit_all_pass": all(x["pass"] for x in text_fit),
            "connector_endpoint_checks": connector_checks,
            "connector_endpoints_all_pass": all(x["start_on_source"] and x["end_on_target"] for x in connector_checks),
            "cross_object_collisions": cross_collisions,
            "free_text_collisions": free_text_collisions,
            "cross_object_collision_matrix_pass": not cross_collisions and not free_text_collisions,
            "connector_body_collisions": connector_body_collisions,
            "connector_text_collisions": connector_text_collisions,
            "connector_body_collision_pass": not connector_body_collisions and not connector_text_collisions,
            "negative_collision_fixtures": negative_fixtures,
            "negative_collision_fixtures_detected": sum(1 for x in negative_fixtures if x["detected"]),
            "generic_filesystem_endpoint_usage": generic_fs_endpoint_usage,
            "material_arrow_whitespace_endpoints": material_arrow_whitespace_endpoints,
            "identity_association_checks": association_checks,
            "access_microgeometry_checks": access_microgeometry,
            "connector_clearance_checks": connector_clearance_checks,
            "read_lane_separation_mm": read_lane_separation_mm,
            "rendered_vector_geometry_qa": rendered_vector_qa,
            "microgeometry_profile": {
                "min_endpoint_corner_clearance_mm": MIN_ENDPOINT_CORNER_CLEARANCE_MM,
                "min_terminal_straight_mm": MIN_TERMINAL_STRAIGHT_MM,
                "local_visible_terminal_target_mm": LOCAL_VISIBLE_TERMINAL_TARGET_MM,
                "min_parallel_lane_separation_mm": MIN_PARALLEL_LANE_SEPARATION_MM,
                "min_connector_text_clearance_mm": MIN_CONNECTOR_TEXT_CLEARANCE_MM,
                "min_connector_panel_clearance_mm": MIN_CONNECTOR_PANEL_CLEARANCE_MM,
                "flow_arrowhead_scale_pt": FLOW_ARROWHEAD_SCALE_PT,
            },
        },
        "svg_structural_readback": {
            "width_pt": width_pt,
            "height_pt": height_pt,
            "width_mm": width_pt * pt_to_mm if width_pt else None,
            "height_mm": height_pt * pt_to_mm if height_pt else None,
            "text_elements": svg.count("<text"),
            "image_elements": svg.count("<image"),
            "path_elements": svg.count("<path"),
            "font_family_present": FONT_FAMILY in svg,
        },
        "critical_material_strings": [
            RUNTIME_BOUNDARY_TEXT,
            "WINDOWS HOST",
            "M4 BEHAVIORAL QUALIFICATION",
            "HOLD_INFRASTRUCTURE_PREMODEL",
            "M4R1 PROSPECTIVE REMEDIATION",
            "HOLD F03",
        ],
        "semantic_invariants": [
            "Figure is a local execution adapter/development-environment view, not the MM architecture itself.",
            "CR-04 actor identities and filesystem authority model are preserved.",
            "Reviewer has no access to mutable output/scratch surfaces.",
            "A1 global scratch outside the primary Gate workspace is not a general child-command writable root.",
            "Controlled toolchain is immutable/root-owned; credentials/config are separate operational state.",
            "M4 behavioral result remains NOT_ESTABLISHED with infrastructure pre-model HOLD.",
            "M4R1 remains HOLD F03; no rerun/runtime authority is implied.",
            "Actor-to-sandbox identity relations are non-directional associations with no arrowheads.",
            "Access flows are directed and terminate on typed flat-boundary ports with perpendicular incidence.",
            "Publication microgeometry is accepted from exported SVG/PDF unoccluded visible-ink measurements after target-panel overpaint/stroke, not nominal source coordinates or path-tip length alone.",
            "Connector labels are black with opaque white backing; colour is used on arrows/keylines as a redundant grouping cue only.",
            "Primary Gate workspace is explicitly bounded within scratch/ without granting global scratch writability.",
            "Qualified local adapter does not imply scientific/GEE/production runtime authorization.",
        ],
        "outputs": {
            svg_path.name: {"bytes": svg_path.stat().st_size, "sha256": sha256(svg_path)},
            pdf_path.name: {"bytes": pdf_path.stat().st_size, "sha256": sha256(pdf_path)},
            png_path.name: {"bytes": png_path.stat().st_size, "sha256": sha256(png_path)},
        },
    }
    manifest_path = outdir / "MM_LOCAL_EXECUTION_ADAPTER_FIGURE_MANIFEST_v1.0.6.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                             encoding="utf-8", newline="\n")
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", default=".")
    args = parser.parse_args()
    print(json.dumps(render(Path(args.outdir)), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
