# Assessor guide — prospective fresh-reader observation

Version 1.0.0. Protocol status PREPARED; participant evaluation NOT_RUN; participants observed 0. The guide and answer discussion are public, so the procedure does not establish blinding.

## Before the session

Agree to the bounded task and the intended use of its observations. Use a participant code rather than unnecessary personal identifiers. Record relevant experience, prior MM familiarity, prior access to the worked example or this guide, and tools/AI permitted. Do not infer skill solely from a job title.

Freeze the task version, selected documentation hashes/URLs and revision, this rubric, assistance rules, and the locally chosen observation/time arrangement. Use one consistent arrangement when comparing sessions; record deviations. No duration threshold has been empirically validated by this protocol.

For the first attempt provide PARTICIPANT_TASK.md, C-INPUT-1/SRS-PERIOD, the selected Methodology phases 0, 1, 5 and 6, the V&V explanation and relevant Manual records. If autonomous transfer is the question, do not initially provide the worked answer, source implementation, fixture results or this assessor discussion. Record any previous or accidental exposure. Public availability cannot be treated as proof of non-exposure.

## Observe without completing the task for the participant

Keep procedural clarification separate from substantive hints. Record the time/order, question, exact assistance and response affected. Save an attributable first-response copy with a timestamp and SHA-256 before feedback. Then, if useful, provide the example or hints and save a separate assisted revision. Never overwrite the first response.

## Rubric

Each competency has three levels: DEMONSTRATED, PARTIALLY_DEMONSTRATED, NOT_DEMONSTRATED. Record evidence location and a brief reason; missing evidence is not automatically evidence of inability. Assistance is a separate field: NONE, PROCEDURAL, SUBSTANTIVE. Do not combine scores into a compensating total.

| Competency | Demonstrated | Partial | Not demonstrated |
|---|---|---|---|
| C1 Need and decisions | States the per-period need, analyst decision and no-carryover/missingness assumptions; distinguishes domain judgment from code | Need is stated, but a consequential assumption or distinction is omitted | Treats a passing total, filled document or code execution as enough to establish fitness |
| C2 Contracts and traceability | Locates the period detector and input/output contract; proposes an explicit version change and links relevant requirements | Identifies the change but leaves a material semantic/traceability gap | Silently maps missing to zero or changes meaning without a declared contract |
| C3 Verification and validation | Names specification as verification reference and users/ConOps/conditions as adequacy reference, with separate evidence | Distinction is stated but one evidence plan is underspecified | Conflates unit-test success with intended-use/scientific validity |
| C4 Prospective acceptance | Freezes examples and criteria before results, including known deficit, unknown period and forbidden all-clear | Useful examples but incomplete conditions or timing | Adjusts criteria after results without a separately recorded prospective revision |
| C5 Limits and justified decision | States what is known, unknown and domain-dependent; gives a scoped decision with needed evidence | Limit recognized but decision or next evidence unclear | Claims complete adequacy from incomplete observations or authorizes scientific execution without authority |

## Assessor discussion — not a substitute for the participant's reasoning

A coherent proposal preserves P03 as UNKNOWN and reports a known deficit of 2 at P04. Missingness must remain visible in both the input contract and output status. An incomplete horizon cannot support a complete “no deficit” or complete “all deficit periods identified” claim. One possible output has known_deficits, unknown_periods and INCOMPLETE status; alternative schemas are acceptable if they preserve the same meaning.

Verification would check that the versioned contract is implemented, including null versus recorded zero, ordering, known deficits, unknown periods and status restrictions. Adequacy assessment would ask whether an analyst can use the incomplete report for the intended decision, under the declared assumptions and with the relevant domain/user confirmation. No participant may turn this synthetic discussion into real-world model validation.

If asked to accept a complete claim about all twelve periods, the appropriate disposition is HOLD for the unknown period. A bounded implementation proposal or known-deficit report may be acceptable for its narrower stated scope. Do not require one specific schema or vocabulary as long as the semantics and justification are sound.

## Session outcomes

- COMPLETED_INDEPENDENTLY_FOR_THIS_TASK: all five competencies demonstrated in the frozen first response without substantive assistance, and exposure/allowed-tool conditions explicitly reported. If prior answer exposure occurred, describe the exposed condition and do not call it a first-contact result.
- COMPLETED_WITH_ASSISTANCE_FOR_THIS_TASK: all five demonstrated only after substantive assistance; retain both responses and identify the assistance.
- NOT_DEMONSTRATED_FOR_THIS_TASK: one or more competencies remain partial/not demonstrated, the session is incomplete or evidence is insufficient. Describe which; do not infer general professional incompetence.

Procedural help must still be reported. Critical misunderstandings about V&V, missingness or unsupported claims cannot be compensated by strengths elsewhere.

## Interpretation

Report omissions, misunderstandings, unsupported decisions and help needed, with examples tied to the exact material. A small pilot identifies local adoption difficulties; it does not estimate success rates for all mid-level or senior developers. This is a proposed observation method, not a completed study or a validated measurement instrument.
