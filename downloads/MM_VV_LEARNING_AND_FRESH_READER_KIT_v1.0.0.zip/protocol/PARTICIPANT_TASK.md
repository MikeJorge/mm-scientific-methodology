# Participant task — missing observations in a period report

Task ID: MM-FRESH-READER-T1, version 1.0.0. This is a bounded transfer task, different from the completed offset-surplus example. No scientific runtime or production repository change is requested.

## Situation

A hypothetical analyst needs to identify every deficit period in a twelve-period horizon. Resources cannot be carried between periods in this exercise. Demand is 10 demo units in each period. Supply is:

`[10, 14, null, 8, 10, 10, 10, 10, 10, 10, 10, 10]`

P03 has no observation. P04 has a recorded supply of 8. The existing contract C-INPUT-1 rejects null. A requested change is: “Permit an incomplete report while keeping the missing period visible; help the analyst understand what can and cannot be concluded.”

Use the selected MM documentation to prepare a proposed change. Do not silently substitute zero for null. You may conclude that an assumption needs confirmation. Actual implementation is optional unless separately agreed; the primary observation is your reasoning and evidence plan.

## Your first response

1. State the user's need and intended decision. Separate scientific/domain assumptions from the programming change.
2. Identify the affected illustrative module, input/output contract and relevant requirements. Explain what must be versioned and what remains an assumption.
3. Write a verification plan and a separate validation/adequacy plan. Name the reference used by each.
4. Declare acceptance criteria, expected examples and conditions that require withholding a conclusion before viewing results of a proposed implementation.
5. Identify what needs a domain specialist, user confirmation or additional evidence. Give a justified accept, reject or hold decision for the proposed next step, limited to its actual evidence.

Record uncertainties and questions. You are not expected to memorize DM identifiers: locating and correctly explaining a relevant record is sufficient. A well-justified limit is evidence of understanding.

## Session conditions

Before beginning, tell the assessor about prior MM experience, relevant engineering experience and previous access to this example or assessor guidance. Use only the agreed materials during the first response. Record all help received, including tools or AI assistance. Freeze your first response before opening a solution or receiving substantive hints. An assisted revision is welcome, but is recorded separately.

This public task is not a blinded examination or a professional certification. Its results describe this task under its recorded conditions.
