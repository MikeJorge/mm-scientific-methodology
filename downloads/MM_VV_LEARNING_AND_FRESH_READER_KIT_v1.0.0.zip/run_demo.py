"""Offline runner. Writes a new attributable receipt; never invents participant data."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
from test_example import run_checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, help="A new, empty output directory")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    stamp = datetime.now(timezone.utc)
    output = args.output or root / "runs" / stamp.strftime("run_%Y%m%dT%H%M%S_%fZ")
    if output.exists():
        parser.error("Output must not already exist; prior evidence is preserved")
    freeze = json.loads((root / "PRE_EXECUTION_FREEZE.json").read_text())
    freeze_ok = all(hashlib.sha256((root / item["path"]).read_bytes()).hexdigest() == item["sha256"]
                    for item in freeze["frozen_files"])
    if not freeze_ok:
        parser.error("Frozen specification/fixtures have changed; no execution performed")
    checks = run_checks()
    passed = all(row["pass"] for row in checks)
    identities = []
    for name in ("CONOPS_AND_ACCEPTANCE.md", "fixtures.json", "PRE_EXECUTION_FREEZE.json",
                 "balance_example.py", "test_example.py", "run_demo.py"):
        data = (root / name).read_bytes()
        identities.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    result = {
        "operation": "EXECUTE_SYNTHETIC_DIDACTIC_EXAMPLE",
        "timestamp_utc": stamp.isoformat(), "python": sys.version.split()[0], "platform": platform.platform(),
        "result": "PASS_DIDACTIC_CHECKS" if passed else "FAIL_DIDACTIC_CHECKS",
        "freeze_identity_check": freeze_ok,
        "checks_passed": sum(row["pass"] for row in checks), "checks_total": len(checks),
        "decisions": {
            "aggregate_verification_reference": "SRS-AGGREGATE v1",
            "aggregate_verification": "PASS" if passed else "NOT_ESTABLISHED",
            "aggregate_against_SRS_PERIOD": "FAIL_MISSING_PERIOD_OUTPUT" if passed else "NOT_ESTABLISHED",
            "aggregate_intended_use": "REJECT_FOR_DECLARED_DIDACTIC_CONOPS" if passed else "NOT_ESTABLISHED",
            "period_verification_reference": "SRS-PERIOD v1",
            "period_verification": "PASS" if passed else "NOT_ESTABLISHED",
            "period_intended_use": "ACCEPT_FOR_DECLARED_DIDACTIC_CONOPS_AND_FIXTURES_ONLY" if passed else "NOT_ESTABLISHED"
        },
        "real_world_model_validation": "NOT_ESTABLISHED",
        "external_developer_evaluation": "NOT_RUN", "human_participants_observed": 0,
        "scientific_runtime_executed": False, "github_writes": 0,
        "identities": identities, "checks": checks
    }
    output.mkdir(parents=True)
    (output / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(result["result"])
    print(f"CHECKS={result['checks_passed']}/{result['checks_total']}")
    print(f"EVIDENCE_DIRECTORY={output.resolve()}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
