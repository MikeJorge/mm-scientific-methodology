# Sources, relationships and claim boundaries

## Primary external conceptual references

- NASA, Systems Engineering Handbook, section 2.4, Distinctions between Product Verification and Product Validation: https://www.nasa.gov/reference/2-4-distinctions-between-product-verification-and-product-validation/ . Accessed 19 November 2026. Basis for separating requirements conformity from intended-purpose fitness in the intended environment, including ConOps and users.
- NASA, IV&V Overview: https://www.nasa.gov/ivv-overview/ . Accessed 19 November 2026. Complementary background for distinct verification and validation questions. The MM illustration is original, not an official NASA figure. This kit does not claim NASA endorsement, certification, formal compliance or NASA IV&V independence.

## Existing MM authority

Manual view: https://mikejorge.github.io/mm-scientific-methodology/audit/manual-requirements/ . Certified Manual identity remains 01e9a94a7909af9436443ad016e5df06302576b4. The learning addition does not amend any DM requirement.

DM-0021/0022 relate to rationale and assumptions; DM-0023 to traceability; DM-0028 to units and temporal semantics; DM-0029 to prospective criteria; DM-0108 to requirement-linked test cases. These are explanatory relationships, not new certifications of compliance.

DM-0155 motivates a fresh-reader walkthrough in its documented workflow-reproduction scope. This smaller comprehension task does not demonstrate restoration of the full scientific workflow. DM-0158 is a conditional SHOULD for executable/tested examples where feasible and scientifically safe; this kit does not convert it into a universal SHALL.

## Rights and preservation

The existing methodology copyright and licensing notice remains controlling: https://mikejorge.github.io/mm-scientific-methodology/legal/copyright-licensing/ . No new or broader license is asserted by this supplement. Existing author attribution, contact channels, certified figures and sources are preserved in the candidate site.

## Evidence labels

Conceptual explanation: source-based interpretation. Expected arithmetic: hand-tabulated synthetic reference, frozen prospectively. Test receipt: actual observed execution of the didactic functions. Human evaluation: NOT_RUN, zero participants. Real-world model validity and empirical adoption effectiveness: NOT_ESTABLISHED. These categories must remain separate.
