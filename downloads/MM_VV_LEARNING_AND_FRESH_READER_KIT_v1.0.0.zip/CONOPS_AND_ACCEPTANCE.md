# Synthetic example: purpose, contract and prospective acceptance

Version: 1.0.0. This file and fixtures.json are frozen before the first execution. See PRE_EXECUTION_FREEZE.json for identities.

## Need and concept of operations

A hypothetical analyst must identify every period in a twelve-period planning horizon in which the available resource is below demand. The analyst uses the report to decide which periods need further investigation. This is an arithmetic teaching exercise, with no biological or economic interpretation.

The units are `demo_units_per_period`. There is **no storage, carryover or compensation between periods**. This is a stipulation of the exercise, not a validated assumption about a real production system. The exercise does not recommend interventions. A domain specialist would have to justify such assumptions and the relationship to a real decision before real-world use.

## C-INPUT-1: data contract shared by both candidates

- The input is a JSON object with exactly four keys: units, periods, supply, demand.
- units is exactly the string `demo_units_per_period`.
- periods is exactly the ordered list P01 through P12, once each.
- supply and demand are lists of exactly twelve values, aligned to those periods.
- Each value is an integer from 0 to 10000 inclusive. Boolean values, fractions, strings, null, negative values and values above the bound are invalid. No coercion is allowed.
- Zero is an observed zero. Missing information is invalid, not zero.
- Invalid inputs raise ContractError before a result is returned.
- Inputs are synthetic. This contract does not define a scientific time scale, calendar or empirical measurement process.

## Two separate specifications

**SRS-AGGREGATE v1:** after validating C-INPUT-1, report total supply, total demand and their difference (supply minus demand), using exact integer arithmetic. This requirement does not promise to identify individual deficit periods.

**SRS-PERIOD v1:** after validating C-INPUT-1, report each period with supply less than demand, in input order, with deficit equal to demand minus supply. Return DEFICIT_PRESENT when the list is nonempty and NO_DEFICIT otherwise. Equality is not a deficit.

The aggregate implementation may pass verification against SRS-AGGREGATE. It cannot pass verification against SRS-PERIOD. The two references must never be conflated.

## Prospective verification plan

V01: compare both functions directly with the hand-tabulated expectations for all six valid fixtures, including zero and the upper allowed value.

V02: require both functions to raise ContractError for every invalid fixture. These cover missing values, negative values, bool, string, fraction, out-of-range value, short arrays, duplicated/out-of-order/missing period identifiers, wrong units, missing/extra keys and a non-object input.

V03: require both functions to leave every supplied input unchanged.

V04: verify the downloaded kit's internal checksums separately; test output is written to a new run directory, not over the frozen fixtures or preparation receipt.

## Prospective adequacy assessment for this hypothetical use

The offset-surplus fixture has demand 10 in each period and supply [10,14,6,10,10,10,10,10,10,10,10,10]. Total supply = 120; total demand = 120; aggregate balance = 0. The independent, direct reference is P03 with a deficit of 4. A surplus in P02 cannot satisfy demand in P03 under the declared no-carryover condition.

Accept the period candidate **for the declared didactic ConOps and fixtures only** when it passes SRS-PERIOD, rejects invalid inputs and reports precisely that deficit. Reject the aggregate-only candidate for that use because its output does not locate the deficit. It remains a correct implementation of SRS-AGGREGATE if its own tests pass.

The fixture expectations were written by direct arithmetic, not by calling either candidate. The adequacy demonstration is a finite scenario comparison; it is not empirical validation of a scientific model, evidence of operational fitness, or evidence that an external developer understands MM.

## Decisions and authority

The exercise author freezes the specification, fixtures and expected results before execution. The observed receipt records the actual comparison. A separate reader can inspect the arithmetic, code and evidence. A real MM gate would still require its own responsible actors, applicability, admissible evidence and authorization; the teaching labels here do not confer that authority.

No installation, network access, GitHub write, scientific model execution or participant observation is required by this example.
