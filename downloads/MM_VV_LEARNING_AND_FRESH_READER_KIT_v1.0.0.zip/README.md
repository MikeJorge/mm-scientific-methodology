# MM verification, validation and fresh-reader learning kit

Kit version 1.0.0. Prepared for the additive MM methodology v1.0.4 candidate. All examples use synthetic arithmetic; no scientific model or real dataset is run.

## Start here

1. Read CONOPS_AND_ACCEPTANCE.md. The verification reference and intended use are different, explicit objects.
2. Read fixtures.json and PRE_EXECUTION_FREEZE.json before reading results.
3. Read balance_example.py and test_example.py; the implementation is deliberately small.
4. With Python 3.10 or newer, run `python run_demo.py` (on Windows, `py -3 run_demo.py` is also suitable). Only the Python standard library is needed. No browser, pip or Internet is required.
5. Inspect the new output directory printed by the command. It contains the exact source identities, test cases and scoped decisions. A failed check exits nonzero.

The preparation receipt is kept under observed_preparation/. Your run creates a different directory under runs/. It does not overwrite the original receipt, fixtures or a participant record.

## Example interpretation

The aggregate function is verified against SRS-AGGREGATE. It is rejected for the hypothetical per-period decision. The period function is verified against SRS-PERIOD and accepted only for the declared didactic ConOps and fixtures. Neither result establishes real-world scientific validity.

## Fresh-reader assessment

Start with protocol/PARTICIPANT_TASK.md. The assessor uses protocol/ASSESSOR_GUIDE.md and copies the blank protocol/OBSERVATION_TEMPLATE.json into a new session directory. Do not fill the distributed template with fictional observations.

The worked example, source and assessor guidance are public materials. Record previous exposure. Freeze the participant's first response before hints or the worked solution; retain any later assisted response separately. Do not call a previously exposed session blind or an assisted response autonomous.

Current state: protocol prepared; external participant evaluation NOT_RUN; human participants observed = 0; empirical adoption effectiveness NOT_ESTABLISHED.

## Verify archive contents

SHA256SUMS.txt lists all other regular files. The release delivery records the archive's own byte count and SHA-256 separately. The kit has no executable installer and does not alter security settings. It inherits the methodology's copyright and licensing terms; no new license grant is asserted. See the linked methodology legal notice and SOURCES.md.
