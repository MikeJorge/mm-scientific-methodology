"""Compare implementation to frozen explicit expectations, without generating an oracle."""
import copy
import json
from pathlib import Path
from balance_example import ContractError, aggregate_balance, period_deficits


def run_checks():
    fixtures = json.loads(Path(__file__).with_name("fixtures.json").read_text(encoding="utf-8"))
    records = []
    for case in fixtures["valid"]:
        for name, function in (("aggregate", aggregate_balance), ("period", period_deficits)):
            data = copy.deepcopy(case["input"])
            before = copy.deepcopy(data)
            try:
                actual = function(data)
                expected = case["expected"][name]
                passed = actual == expected and data == before
                records.append({"case": case["id"], "function": name, "pass": passed,
                                "expected": expected, "actual": actual, "input_unchanged": data == before})
            except Exception as exc:
                records.append({"case": case["id"], "function": name, "pass": False,
                                "unexpected_error": type(exc).__name__ + ": " + str(exc)})
    for case in fixtures["invalid"]:
        for name, function in (("aggregate", aggregate_balance), ("period", period_deficits)):
            data = copy.deepcopy(case["input"])
            before = copy.deepcopy(data)
            try:
                actual = function(data)
                records.append({"case": case["id"], "function": name, "pass": False,
                                "expected": "ContractError", "actual": actual})
            except ContractError:
                records.append({"case": case["id"], "function": name, "pass": data == before,
                                "expected": "ContractError", "actual": "ContractError",
                                "input_unchanged": data == before})
            except Exception as exc:
                records.append({"case": case["id"], "function": name, "pass": False,
                                "unexpected_error": type(exc).__name__ + ": " + str(exc)})
    return records


if __name__ == "__main__":
    results = run_checks()
    print(json.dumps(results, indent=2))
    raise SystemExit(0 if all(row["pass"] for row in results) else 1)
