"""Bounded synthetic arithmetic for learning, not a scientific runtime."""

PERIODS = [f"P{i:02d}" for i in range(1, 13)]
KEYS = {"units", "periods", "supply", "demand"}


class ContractError(ValueError):
    """The input does not satisfy C-INPUT-1."""


def validate_input(data):
    if type(data) is not dict or set(data) != KEYS:
        raise ContractError("Exactly units, periods, supply and demand are required")
    if data["units"] != "demo_units_per_period":
        raise ContractError("The declared illustrative unit is required")
    if type(data["periods"]) is not list or data["periods"] != PERIODS:
        raise ContractError("Periods must be P01 through P12, once each, in order")
    for field in ("supply", "demand"):
        values = data[field]
        if type(values) is not list or len(values) != 12:
            raise ContractError(f"{field} must contain exactly twelve observations")
        if any(type(v) is not int or not 0 <= v <= 10000 for v in values):
            raise ContractError(f"{field} requires integers in [0, 10000]; no coercion")


def aggregate_balance(data):
    """Implements SRS-AGGREGATE; does not claim per-period adequacy."""
    validate_input(data)
    supply = sum(data["supply"])
    demand = sum(data["demand"])
    return {"total_supply": supply, "total_demand": demand, "balance": supply - demand}


def period_deficits(data):
    """Implements SRS-PERIOD under the declared no-carryover condition."""
    validate_input(data)
    deficits = [
        {"period": p, "deficit": d - s}
        for p, s, d in zip(data["periods"], data["supply"], data["demand"])
        if s < d
    ]
    return {"deficits": deficits, "status": "DEFICIT_PRESENT" if deficits else "NO_DEFICIT"}
